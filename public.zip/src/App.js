import React from "react";
import { motion } from "framer-motion";
import "./App.css";

// Logo and images
const logo = "/chantLogo.JPG";
const images = [
  { src: "/image1.jpeg", alt: "Ganesha Idol 1" },
  { src: "/image2.jpeg", alt: "Ganesha Idol 2" },
  { src: "/image3.jpeg", alt: "Ganesha and Krishna Idols" },
];

function App() {
  return (
    <main className="main-wrapper">
      {/* Header */}
      <header className="app-header">
        <img src={logo} alt="Namma Ganesha Logo" className="logo" />
        <motion.h1
          className="title"
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          Namma Ganesha
        </motion.h1>
      </header>

      {/* Animated "Coming Soon" Text */}
      <motion.h2
        className="coming-soon"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.5, repeat: Infinity, repeatType: "reverse" }}
      >
        Coming Soon...
      </motion.h2>

      {/* Intro */}
      <section className="description">
        <h3>Chant. Record. Request.</h3>
        <p>
          <strong>Namma Ganesha</strong> helps you log Japa, view your history, and send requests to the priest — all in one place.
        </p>
      </section>

      {/* Image Gallery Row */}
      <section className="row">
        {images.slice(0, 2).map((img, index) => (
          <motion.div
            key={index}
            className="card half"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 * index, duration: 0.5 }}
          >
            <img src={img.src} alt={img.alt} className="gallery-img" />
          </motion.div>
        ))}
      </section>

      {/* Center Image */}
      <motion.div
        className="card image3-wrapper"
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.4, duration: 0.6 }}
      >
        <img src={images[2].src} alt={images[2].alt} className="image3-img" />
      </motion.div>

      {/* Additional Text */}
      <section className="description">
        <p>
          NammaGanesha is your trusted digital companion for spiritual practice. Designed with simplicity and devotion in mind, this app helps you count and track your Japa (mantra chanting) anytime, anywhere — all while staying connected to your daily goals and inner peace.
        </p>
      </section>

      {/* Footer */}
      <footer className="footer">
        © {new Date().getFullYear()} Temple Devotion. All rights reserved.
      </footer>
    </main>
  );
}

export default App;
